//
//  ViewController.swift
//  App2
//
//  Created by Aakriti  Mahajan on 2/20/16.
//  Copyright © 2016 Aakriti  Mahajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //object references
    @IBOutlet weak var QuestionLabel: UILabel!
    @IBOutlet weak var Button1: UIButton!
    @IBOutlet weak var Button2: UIButton!
    @IBOutlet weak var Button3: UIButton!
    @IBOutlet weak var Button4: UIButton!
    
    var CorrectAnswer = String()
    
    @IBOutlet weak var LabelEnd: UILabel!
    @IBOutlet weak var NextQuestion: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        Hide()
        RandomQuestions()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func RandomQuestions(){
        // These two lines genereate random numbers. The line makes a random variable from 0 - 4 and the second line adds one to it to make it a random variable from 1-5
    
        var RandomNumber = arc4random() % 5
        RandomNumber += 1
        // Add questions here! For each questoin you add increment the number in var Random (ex six questions would
        //have var RandomNumber = arc4random() % 6 if there were 6 question.
        //for each question set your correct answer to the number.
        switch(RandomNumber){
            case 1:
                QuestionLabel.text = "Hello World, What is My Name"
                Button1.setTitle("Aakriti", forState: UIControlState.Normal)
                Button2.setTitle("Bob", forState: UIControlState.Normal)
                Button3.setTitle("Tom", forState: UIControlState.Normal)
                Button4.setTitle("Akriti", forState: UIControlState.Normal)
                
                CorrectAnswer = "1"
                break
            case 2:
                QuestionLabel.text = "What is my last name"
                Button1.setTitle("Mahajan", forState: UIControlState.Normal)
                Button2.setTitle("Mahjan", forState: UIControlState.Normal)
                Button3.setTitle("White", forState: UIControlState.Normal)
                Button4.setTitle("Brown", forState: UIControlState.Normal)
                
                CorrectAnswer = "1"
                break
            case 3:
                QuestionLabel.text = "What is my cats name"
                Button1.setTitle("Nick", forState: UIControlState.Normal)
                Button2.setTitle("Queenie", forState: UIControlState.Normal)
                Button3.setTitle("Tabbs", forState: UIControlState.Normal)
                Button4.setTitle("Nikki", forState: UIControlState.Normal)
                
                CorrectAnswer = "4"
                break
            case 4:
                QuestionLabel.text = "What is my birthday "
                Button1.setTitle("July 10", forState: UIControlState.Normal)
                Button2.setTitle("June 10", forState: UIControlState.Normal)
                Button3.setTitle("July 6", forState: UIControlState.Normal)
                Button4.setTitle("June 6", forState: UIControlState.Normal)
                
                CorrectAnswer = "3"
                break
            case 5:
                QuestionLabel.text = "What is my favorite color  "
                Button1.setTitle("pink", forState: UIControlState.Normal)
                Button2.setTitle("blue", forState: UIControlState.Normal)
                Button3.setTitle("red", forState: UIControlState.Normal)
                Button4.setTitle("yellow", forState: UIControlState.Normal)
            
                CorrectAnswer = "1"
                break
            
            
            
            default:
                break
        }
        
    }
    //these functions hide and unhide the answer label and the next question button. Try modifying them/ commenting some out and see how it affects the code!
    func Hide(){
        LabelEnd.hidden = true;
        NextQuestion.hidden = true;
    }
    func unHide(){
        LabelEnd.hidden = false;
        NextQuestion.hidden = false;
    }
    
    //Actions -button actions are called when a button is pressed!
    @IBAction func Button1Action(sender: AnyObject) {
        unHide()
        if(CorrectAnswer == "1"){
            LabelEnd.text = "You Are Correct"
        }
        else{
            LabelEnd.text = "You Are Wrong"
        }
        
        
    }
    @IBAction func Button2Action(sender: AnyObject) {
        unHide()
        if(CorrectAnswer == "2"){
            LabelEnd.text = "You Are Correct"
        }
        else{
            LabelEnd.text = "You Are Wrong"
        }
    }
    @IBAction func Button3Action(sender: AnyObject) {
        unHide()
        if(CorrectAnswer == "3"){
            LabelEnd.text = "You Are Correct"
        }
        else{
            LabelEnd.text = "You Are Wrong"
        }
    }
    @IBAction func Button4Action(sender: AnyObject) {
        unHide()
        if(CorrectAnswer == "4"){
            LabelEnd.text = "You Are Correct"
        }
        else{
            LabelEnd.text = "You Are Wrong"
        }
    }
    
    @IBAction func Next(sender: AnyObject) {
        RandomQuestions()
        Hide()
    }
    

}

